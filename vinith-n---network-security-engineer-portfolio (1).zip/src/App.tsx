/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Stats } from './components/Stats';
import { About } from './components/About';
import { Experience } from './components/Experience';
import { SkillsExpertise } from './components/SkillsExpertise';
import { FirewallSimulator } from './components/FirewallSimulator';
import { Projects } from './components/Projects';
import { Certifications } from './components/Certifications';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ResumeModal } from './components/ResumeModal';
import { CyberTerminal } from './components/CyberTerminal';

export default function App() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 font-sans selection:bg-cyan-500 selection:text-slate-950 ${
      theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      {/* Navigation Bar */}
      <Navbar
        theme={theme}
        toggleTheme={toggleTheme}
        openResume={() => setIsResumeOpen(true)}
        openTerminal={() => setIsTerminalOpen(true)}
      />

      {/* Hero Section */}
      <Hero
        theme={theme}
        openResume={() => setIsResumeOpen(true)}
        openTerminal={() => setIsTerminalOpen(true)}
      />

      {/* Key Stats Bar */}
      <Stats theme={theme} />

      {/* About Section */}
      <About theme={theme} />

      {/* Experience Timeline Section */}
      <Experience theme={theme} />

      {/* Technical Expertise & Security Tools */}
      <SkillsExpertise theme={theme} />

      {/* Interactive Firewall Rule Generator & Policy Auditor */}
      <FirewallSimulator theme={theme} />

      {/* Featured Projects & Case Studies */}
      <Projects theme={theme} />

      {/* Certifications Section */}
      <Certifications theme={theme} />

      {/* Contact Section */}
      <Contact theme={theme} />

      {/* Footer */}
      <Footer theme={theme} />

      {/* Resume Viewer / Printable PDF Modal */}
      <ResumeModal
        isOpen={isResumeOpen}
        onClose={() => setIsResumeOpen(false)}
        theme={theme}
      />

      {/* Interactive Cyber Terminal CLI */}
      <CyberTerminal
        isOpen={isTerminalOpen}
        onClose={() => setIsTerminalOpen(false)}
        theme={theme}
      />
    </div>
  );
}
