import React from 'react';
import { Briefcase, Calendar, MapPin, CheckCircle, Building } from 'lucide-react';
import { EXPERIENCES } from '../data/portfolioData';

interface ExperienceProps {
  theme: 'dark' | 'light';
}

export const Experience: React.FC<ExperienceProps> = ({ theme }) => {
  return (
    <section id="experience" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Briefcase className="w-3.5 h-3.5" />
            <span>CAREER PATH</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            theme === 'dark' ? 'text-white' : 'text-slate-900'
          }`}>
            Professional <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Experience</span>
          </h2>
          <p className={`text-sm sm:text-base ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
            Track record in managing network security infrastructure, performing VAPT assessments, and automating operations.
          </p>
        </div>

        {/* Timeline Container */}
        <div className="relative max-w-4xl mx-auto">
          {/* Vertical Center Line */}
          <div className={`absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 -translate-x-1/2 ${
            theme === 'dark' ? 'bg-slate-800' : 'bg-slate-200'
          }`} />

          <div className="space-y-12">
            {EXPERIENCES.map((exp, index) => {
              const isEven = index % 2 === 0;
              return (
                <div
                  key={exp.id}
                  className={`relative flex flex-col md:flex-row items-start ${
                    isEven ? 'md:flex-row-reverse' : ''
                  }`}
                >
                  {/* Timeline Dot */}
                  <div className="absolute left-4 md:left-1/2 -translate-x-1/2 top-1.5 z-10">
                    <div className="w-9 h-9 rounded-full bg-slate-950 border-2 border-cyan-400 flex items-center justify-center text-cyan-400 shadow-md shadow-cyan-500/20">
                      <Building className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Content Card */}
                  <div className="ml-12 md:ml-0 md:w-1/2 md:px-8 w-full">
                    <div
                      className={`p-6 sm:p-7 rounded-2xl border transition-all duration-300 hover:shadow-xl hover:border-cyan-500/40 ${
                        theme === 'dark'
                          ? 'bg-slate-900/80 border-slate-800 shadow-lg shadow-black/20'
                          : 'bg-white border-slate-200 shadow-md'
                      }`}
                    >
                      {/* Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                        <span className="px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                          {exp.period}
                        </span>
                        <span className={`text-xs font-mono flex items-center gap-1 ${
                          theme === 'dark' ? 'text-slate-400' : 'text-slate-500'
                        }`}>
                          <MapPin className="w-3.5 h-3.5 text-cyan-500" />
                          {exp.location}
                        </span>
                      </div>

                      <h3 className={`text-xl font-extrabold ${
                        theme === 'dark' ? 'text-white' : 'text-slate-900'
                      }`}>
                        {exp.role}
                      </h3>

                      <h4 className="text-sm font-semibold text-cyan-400 mb-4 flex items-center gap-1.5">
                        <Building className="w-4 h-4" />
                        <span>{exp.company}</span>
                        <span className="text-slate-500">• {exp.type}</span>
                      </h4>

                      {/* Responsibilities list */}
                      <ul className="space-y-2.5 mb-5 text-xs sm:text-sm">
                        {exp.responsibilities.map((task, i) => (
                          <li key={i} className="flex items-start gap-2.5">
                            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                            <span className={theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}>
                              {task}
                            </span>
                          </li>
                        ))}
                      </ul>

                      {/* Skills Tags */}
                      <div className="pt-3 border-t border-slate-800/60 flex flex-wrap gap-1.5">
                        {exp.skillsUsed.map((skill) => (
                          <span
                            key={skill}
                            className={`px-2.5 py-1 rounded-md text-[11px] font-mono ${
                              theme === 'dark'
                                ? 'bg-slate-950 text-slate-300 border border-slate-800'
                                : 'bg-slate-100 text-slate-700 border border-slate-200'
                            }`}
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
