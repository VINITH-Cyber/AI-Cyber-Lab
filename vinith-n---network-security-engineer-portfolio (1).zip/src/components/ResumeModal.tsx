import React from 'react';
import { X, Printer, Download, Mail, Phone, MapPin, Globe, Shield, CheckCircle } from 'lucide-react';
import { PERSONAL_INFO, EXPERIENCES, TECHNICAL_EXPERTISE, CERTIFICATIONS } from '../data/portfolioData';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: 'dark' | 'light';
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, theme }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fadeIn overflow-y-auto">
      <div className={`relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl border shadow-2xl p-6 sm:p-10 ${
        theme === 'dark' ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800 print:hidden">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-cyan-400" />
            <span className="font-mono font-bold text-sm text-cyan-400">VINITH N — OFFICIAL CURRICULUM VITAE</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 rounded-xl text-xs font-mono font-bold bg-cyan-500 text-slate-950 hover:bg-cyan-400 transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Resume Content Container */}
        <div className="space-y-8 font-sans print:text-black print:bg-white" id="resume-printable-area">
          {/* Resume Header */}
          <div className="border-b pb-6 border-slate-800/80">
            <h1 className="text-3xl font-extrabold tracking-tight mb-1">{PERSONAL_INFO.name}</h1>
            <p className="text-cyan-400 font-mono font-bold text-base mb-4">{PERSONAL_INFO.title}</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-2 text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5 text-cyan-400" /> {PERSONAL_INFO.email}</span>
              <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-cyan-400" /> {PERSONAL_INFO.location}</span>
            </div>
          </div>

          {/* Professional Summary */}
          <div>
            <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400 mb-2">Professional Summary</h2>
            <p className="text-sm leading-relaxed text-slate-300 print:text-slate-800">
              {PERSONAL_INFO.aboutBio}
            </p>
          </div>

          {/* Experience Section */}
          <div>
            <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400 mb-4">Work Experience</h2>
            <div className="space-y-6">
              {EXPERIENCES.map((exp) => (
                <div key={exp.id} className="space-y-2">
                  <div className="flex flex-wrap justify-between items-baseline">
                    <h3 className="text-base font-bold text-white print:text-black">{exp.role} — <span className="text-cyan-400">{exp.company}</span></h3>
                    <span className="text-xs font-mono text-slate-400">{exp.period} | {exp.location}</span>
                  </div>
                  <ul className="space-y-1 text-xs text-slate-300 print:text-slate-800 list-disc list-inside">
                    {exp.responsibilities.map((resp, i) => (
                      <li key={i}>{resp}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Core Technical Expertise */}
          <div>
            <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400 mb-3">Technical Competencies</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <strong className="block font-mono text-cyan-300 mb-1">Firewalls & Security:</strong>
                <p className="text-slate-300 print:text-slate-800">Sophos Firewall (SFOS v21), Fortinet FortiGate (7.6), Cisco FMC, VPN (IPsec/SSL), HA, NAT, Access Control Lists.</p>
              </div>
              <div>
                <strong className="block font-mono text-cyan-300 mb-1">Tools & Platforms:</strong>
                <p className="text-slate-300 print:text-slate-800">Burp Suite Pro, Tenable Nessus, Nmap, Wireshark, Metasploit, Kali Linux, Windows Server, Active Directory.</p>
              </div>
            </div>
          </div>

          {/* Certifications */}
          <div>
            <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400 mb-3">Certifications</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
              {CERTIFICATIONS.map((cert) => (
                <div key={cert.id} className="flex items-center gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{cert.title} ({cert.code})</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
