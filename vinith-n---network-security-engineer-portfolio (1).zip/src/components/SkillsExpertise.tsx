import React, { useState } from 'react';
import { Flame, Shield, Server, Search, Code, FileSearch, Target, Wrench, Check } from 'lucide-react';
import { TECHNICAL_EXPERTISE, SECURITY_TOOLS } from '../data/portfolioData';

interface SkillsProps {
  theme: 'dark' | 'light';
}

export const SkillsExpertise: React.FC<SkillsProps> = ({ theme }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const iconsMap: Record<string, React.ReactNode> = {
    Flame: <Flame className="w-6 h-6 text-orange-400" />,
    Shield: <Shield className="w-6 h-6 text-cyan-400" />,
    Server: <Server className="w-6 h-6 text-blue-400" />,
    Search: <Search className="w-6 h-6 text-purple-400" />,
    Code: <Code className="w-6 h-6 text-emerald-400" />,
    FileSearch: <FileSearch className="w-6 h-6 text-amber-400" />,
    Target: <Target className="w-6 h-6 text-rose-400" />,
    Wrench: <Wrench className="w-6 h-6 text-indigo-400" />
  };

  const categories = [
    { id: 'all', label: 'All Expertise' },
    { id: 'firewall', label: 'Firewalls' },
    { id: 'network-sec', label: 'Network Sec' },
    { id: 'vapt', label: 'VAPT & Audit' },
    { id: 'automation', label: 'Automation' }
  ];

  const filteredItems = activeCategory === 'all'
    ? TECHNICAL_EXPERTISE
    : TECHNICAL_EXPERTISE.filter(item => item.id.includes(activeCategory) || activeCategory === item.id);

  return (
    <section id="skills" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Wrench className="w-3.5 h-3.5" />
            <span>TECHNICAL CAPABILITIES</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            theme === 'dark' ? 'text-white' : 'text-slate-900'
          }`}>
            Technical <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Expertise</span>
          </h2>
          <p className={`text-sm sm:text-base ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
            Deep competence across firewall administration, vulnerability management, server hardening, and security scripting.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-semibold transition-all ${
                activeCategory === cat.id
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/20 font-bold'
                  : theme === 'dark'
                  ? 'bg-slate-900 border border-slate-800 text-slate-300 hover:border-slate-700'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Expertise Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className={`p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1 hover:border-cyan-500/40 flex flex-col justify-between ${
                theme === 'dark'
                  ? 'bg-slate-900/80 border-slate-800 shadow-lg shadow-black/20'
                  : 'bg-white border-slate-200 shadow-md'
              }`}
            >
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className={`p-3 rounded-xl border shrink-0 ${
                    theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
                  }`}>
                    {iconsMap[item.icon] || <Shield className="w-6 h-6 text-cyan-400" />}
                  </div>
                  <h3 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                    {item.title}
                  </h3>
                </div>

                <p className={`text-xs sm:text-sm leading-relaxed mb-6 ${
                  theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  {item.description}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-800/60 flex flex-wrap gap-1.5">
                {item.tags.map((tag) => (
                  <span
                    key={tag}
                    className={`px-2.5 py-1 rounded-md text-xs font-mono font-medium ${
                      theme === 'dark'
                        ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/20'
                        : 'bg-cyan-50 text-cyan-800 border border-cyan-200'
                    }`}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Security Tools & Platforms Bar */}
        <div className={`p-8 rounded-2xl border ${
          theme === 'dark'
            ? 'bg-slate-900/90 border-slate-800'
            : 'bg-slate-900 text-white border-slate-800 shadow-xl'
        }`}>
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-6">
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Wrench className="w-5 h-5 text-cyan-400" />
                <span>Security Tools & Technologies</span>
              </h3>
              <p className="text-xs text-slate-400">
                Daily operational mastery across penetration testing, monitoring, and firewall suites.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full text-xs font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              15+ Enterprise Platforms
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {SECURITY_TOOLS.map((tool) => (
              <div
                key={tool.name}
                className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-cyan-500/50 transition-colors flex flex-col items-center text-center space-y-1"
              >
                <Check className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-white font-mono">{tool.name}</span>
                <span className="text-[10px] text-slate-400">{tool.cat}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
