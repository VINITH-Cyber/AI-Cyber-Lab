import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, X, Maximize2, Minimize2, Check, Copy } from 'lucide-react';
import { PERSONAL_INFO, EXPERIENCES, PROJECTS, CERTIFICATIONS } from '../data/portfolioData';

interface TerminalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: 'dark' | 'light';
}

interface LogEntry {
  command?: string;
  output: string | React.ReactNode;
  type?: 'cmd' | 'info' | 'success' | 'error' | 'system';
}

export const CyberTerminal: React.FC<TerminalProps> = ({ isOpen, onClose, theme }) => {
  const [inputVal, setInputVal] = useState('');
  const [isMaximized, setIsMaximized] = useState(false);
  const [history, setHistory] = useState<LogEntry[]>([
    {
      type: 'system',
      output: `Welcome to Vinith N's Security Console [v2.1.0]
Type 'help' to display all available interactive CLI commands.`
    }
  ]);

  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  if (!isOpen) return null;

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = inputVal.trim().toLowerCase();
    if (!cmd) return;

    const newEntries: LogEntry[] = [{ command: inputVal, output: '', type: 'cmd' }];

    switch (cmd) {
      case 'help':
        newEntries.push({
          type: 'info',
          output: `Available CLI Commands:
• help           : Display this help message
• whoami         : View engineer bio & current role
• skills         : List top firewall & security expertise
• certs          : Display all 5+ verified certifications
• projects       : List key featured security projects
• scan           : Run simulated port/vulnerability scan
• contact        : Display contact details & direct links
• clear          : Clear terminal screen`
        });
        break;

      case 'whoami':
        newEntries.push({
          type: 'info',
          output: `${PERSONAL_INFO.name} — ${PERSONAL_INFO.title}
Location: ${PERSONAL_INFO.location}
Current Company: GTS Technosoft Pvt. Ltd.
Focus: Enterprise Firewalls (Sophos, Fortinet, Cisco), Patch Management, VAPT, Python Automation.`
        });
        break;

      case 'skills':
        newEntries.push({
          type: 'info',
          output: `FIREWALL & NETWORK SECURITY SKILLS:
1. Sophos Firewall (SFOS v21.0 / XGS)
2. Fortinet FortiGate (FortiOS 7.6)
3. Cisco FMC (Secure Firewall Management Center)
4. Tenable Nessus Vulnerability Scanner
5. Burp Suite Pro, Nmap, Wireshark, Metasploit
6. Windows Server Patching & Active Directory
7. Python Security Automation & Log Analytics`
        });
        break;

      case 'certs':
        newEntries.push({
          type: 'info',
          output: `VERIFIED CERTIFICATIONS:
✓ Fortinet Certified Professional (FortiGate Administrator 7.6)
✓ Sophos Firewall Engineer (SFOS v21.0)
✓ Sophos Central Endpoint Protection Engineer
✓ Ruckus SmartZone Administrator (RASZA)
✓ Ruckus Accredited Wi-Fi Designer (RAWD)
✓ AWS Certified Cloud Practitioner`
        });
        break;

      case 'projects':
        newEntries.push({
          type: 'info',
          output: `FEATURED PROJECTS:
1. Railway Infrastructure Network Security (Firewalls & Hardening)
2. Web Application Penetration Testing (OWASP Top 10)
3. Python Security Automation & Syslog Analyzer`
        });
        break;

      case 'scan':
        newEntries.push({
          type: 'success',
          output: `[+] Initiating Nmap simulated stealth scan on 192.168.1.0/24...
[+] Host 192.168.1.1 (Sophos_Firewall_GW) is UP (0.8ms latency).
[+] PORT 22/tcp OPEN (SSH)
[+] PORT 443/tcp OPEN (HTTPS_Management)
[+] PORT 8443/tcp OPEN (SSL_VPN_Portal)
[+] Security Assessment: Zero unpatched critical CVEs found. Firewall rules compliant.`
        });
        break;

      case 'contact':
        newEntries.push({
          type: 'info',
          output: `CONTACT DETAILS:
Email   : ${PERSONAL_INFO.email}
LinkedIn: ${PERSONAL_INFO.linkedin}
GitHub  : ${PERSONAL_INFO.github}`
        });
        break;

      case 'clear':
        setHistory([]);
        setInputVal('');
        return;

      default:
        newEntries.push({
          type: 'error',
          output: `Command not recognized: '${cmd}'. Type 'help' for available commands.`
        });
        break;
    }

    setHistory((prev) => [...prev, ...newEntries]);
    setInputVal('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div
        className={`relative w-full rounded-2xl border border-slate-800 bg-slate-950 shadow-2xl flex flex-col font-mono text-xs transition-all duration-300 ${
          isMaximized ? 'h-[95vh] max-w-7xl' : 'h-[600px] max-w-3xl'
        }`}
      >
        {/* Terminal Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800 rounded-t-2xl">
          <div className="flex items-center gap-2">
            <TerminalIcon className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-300 font-bold">vinith@sec-node:~</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMaximized(!isMaximized)}
              className="p-1 rounded text-slate-400 hover:text-white"
            >
              {isMaximized ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-red-500/20"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Terminal Body */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 text-slate-200">
          {history.map((entry, idx) => (
            <div key={idx} className="space-y-1">
              {entry.command && (
                <div className="flex items-center gap-2 text-cyan-400 font-bold">
                  <span>vinith@sec-node:~$</span>
                  <span>{entry.command}</span>
                </div>
              )}

              {entry.output && (
                <pre
                  className={`whitespace-pre-wrap font-mono leading-relaxed pl-4 border-l-2 ${
                    entry.type === 'error'
                      ? 'border-rose-500 text-rose-300'
                      : entry.type === 'success'
                      ? 'border-emerald-500 text-emerald-300'
                      : 'border-cyan-500/40 text-slate-300'
                  }`}
                >
                  {entry.output}
                </pre>
              )}
            </div>
          ))}
          <div ref={endRef} />
        </div>

        {/* Command Form Prompt Input */}
        <form onSubmit={handleCommand} className="p-3 bg-slate-900/90 border-t border-slate-800 flex items-center gap-2 rounded-b-2xl">
          <span className="text-emerald-400 font-bold">vinith@sec-node:~$</span>
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder="Type 'help', 'skills', 'scan'..."
            className="flex-1 bg-transparent border-none text-emerald-300 font-mono text-xs focus:outline-none"
            autoFocus
          />
          <button type="submit" className="px-3 py-1 bg-emerald-500/20 text-emerald-400 rounded text-[11px] font-bold border border-emerald-500/30">
            EXECUTE
          </button>
        </form>
      </div>
    </div>
  );
};
