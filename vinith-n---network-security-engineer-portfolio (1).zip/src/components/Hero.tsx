import React, { useState, useEffect } from 'react';
import { Shield, Download, Eye, Terminal, CheckCircle, ArrowRight, Lock, Server } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface HeroProps {
  theme: 'dark' | 'light';
  openResume: () => void;
  openTerminal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ theme, openResume, openTerminal }) => {
  const [roleIndex, setRoleIndex] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentRole = PERSONAL_INFO.typingRoles[roleIndex];
    const typingSpeed = isDeleting ? 40 : 80;

    const timeout = setTimeout(() => {
      if (!isDeleting && displayText === currentRole) {
        setTimeout(() => setIsDeleting(true), 1800);
      } else if (isDeleting && displayText === '') {
        setIsDeleting(false);
        setRoleIndex((prev) => (prev + 1) % PERSONAL_INFO.typingRoles.length);
      } else {
        const nextText = isDeleting
          ? currentRole.substring(0, displayText.length - 1)
          : currentRole.substring(0, displayText.length + 1);
        setDisplayText(nextText);
      }
    }, typingSpeed);

    return () => clearTimeout(timeout);
  }, [displayText, isDeleting, roleIndex]);

  return (
    <section id="home" className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden">
      {/* Background Decorative Tech Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className={`absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full blur-3xl opacity-20 ${
            theme === 'dark' ? 'bg-cyan-500' : 'bg-blue-300'
          }`}
        />
        <div
          className={`absolute top-1/3 right-10 w-[400px] h-[400px] rounded-full blur-3xl opacity-15 ${
            theme === 'dark' ? 'bg-blue-600' : 'bg-cyan-200'
          }`}
        />
        <div
          className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)`,
            backgroundSize: '24px 24px'
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Main Hero Column */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Status Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-mono font-medium border bg-cyan-500/10 text-cyan-400 border-cyan-500/30">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>Available for Network & Cyber Security Roles</span>
            </div>

            {/* Main Headline */}
            <div className="space-y-2">
              <h1 className={`text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight ${
                theme === 'dark' ? 'text-white' : 'text-slate-900'
              }`}>
                Hi, I'm <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500 bg-clip-text text-transparent">Vinith N</span>
              </h1>
              
              {/* Typewriter Subheading */}
              <div className="h-10 sm:h-12 flex items-center justify-center lg:justify-start">
                <span className={`text-xl sm:text-2xl font-mono font-bold ${
                  theme === 'dark' ? 'text-cyan-300' : 'text-cyan-700'
                }`}>
                  {displayText}
                  <span className="animate-pulse ml-1 text-cyan-400">|</span>
                </span>
              </div>
            </div>

            {/* Paragraph Bio summary */}
            <p className={`text-base sm:text-lg max-w-2xl mx-auto lg:mx-0 leading-relaxed ${
              theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
            }`}>
              Securing Networks &nbsp;|&nbsp; Enterprise Firewall Administration &nbsp;|&nbsp; Python Automation &nbsp;|&nbsp; Vulnerability Remediation
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
              <button
                onClick={openResume}
                id="hero-download-resume-btn"
                className="px-6 py-3.5 rounded-xl text-sm font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-lg shadow-cyan-500/25 transition-all transform hover:-translate-y-0.5 flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>View & Download Resume</span>
              </button>

              <a
                href="#projects"
                id="hero-view-projects-btn"
                className={`px-6 py-3.5 rounded-xl text-sm font-semibold border transition-all transform hover:-translate-y-0.5 flex items-center gap-2 ${
                  theme === 'dark'
                    ? 'bg-slate-900/80 hover:bg-slate-800 border-slate-700 text-slate-200'
                    : 'bg-white hover:bg-slate-50 border-slate-300 text-slate-800 shadow-sm'
                }`}
              >
                <Eye className="w-4 h-4 text-cyan-500" />
                <span>View Projects</span>
              </a>

              <button
                onClick={openTerminal}
                id="hero-terminal-btn"
                className={`px-4 py-3.5 rounded-xl text-sm font-mono font-medium border transition-all flex items-center gap-2 ${
                  theme === 'dark'
                    ? 'bg-slate-900 border-slate-800 text-emerald-400 hover:border-emerald-500/40 hover:bg-slate-800'
                    : 'bg-slate-100 border-slate-200 text-emerald-700 hover:border-emerald-400 hover:bg-emerald-50'
                }`}
              >
                <Terminal className="w-4 h-4 text-emerald-500" />
                <span>CLI Terminal</span>
              </button>
            </div>

            {/* Quick Tech Highlights Badge */}
            <div className="pt-4 flex flex-wrap justify-center lg:justify-start gap-2 text-xs font-mono">
              {['Sophos Firewall', 'Fortinet FortiGate', 'Cisco FMC', 'Burp Suite', 'Tenable Nessus', 'Python'].map((tech) => (
                <span
                  key={tech}
                  className={`px-3 py-1 rounded-md border ${
                    theme === 'dark'
                      ? 'bg-slate-900/60 border-slate-800 text-slate-400'
                      : 'bg-slate-100 border-slate-200 text-slate-600'
                  }`}
                >
                  #{tech}
                </span>
              ))}
            </div>
          </div>

          {/* Visual Avatar / Cyber Card Column */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative group w-full max-w-sm">
              {/* Outer Cyber Glow Effect */}
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 opacity-40 blur-xl group-hover:opacity-75 transition duration-500" />

              {/* Card Container */}
              <div className={`relative rounded-2xl border p-6 shadow-2xl transition-all duration-300 ${
                theme === 'dark'
                  ? 'bg-slate-900/90 border-slate-800 backdrop-blur-md'
                  : 'bg-white border-slate-200 shadow-xl'
              }`}>
                {/* Header status inside card */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800/50 mb-6">
                  <div className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-cyan-400" />
                    <span className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400">
                      SECURED NODE
                    </span>
                  </div>
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  </div>
                </div>

                {/* Profile Avatar Frame */}
                <div className="relative mx-auto w-44 h-44 mb-6 rounded-2xl overflow-hidden border-2 border-cyan-500/40 shadow-inner group-hover:border-cyan-400 transition-colors bg-gradient-to-tr from-slate-950 to-slate-900 flex flex-col items-center justify-center text-center p-4">
                  {/* High Quality Stylized Tech Avatar Graphic */}
                  <div className="relative z-10 flex flex-col items-center">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 p-1 shadow-lg shadow-cyan-500/30 mb-2 flex items-center justify-center">
                      <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center text-cyan-400">
                        <Shield className="w-10 h-10" />
                      </div>
                    </div>
                    <span className="text-xs font-bold text-white tracking-wide">Vinith N</span>
                    <span className="text-[10px] font-mono text-cyan-400">GTS Technosoft</span>
                  </div>

                  {/* Grid Lines Overlay */}
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#0284c715_1px,transparent_1px),linear-gradient(to_bottom,#0284c715_1px,transparent_1px)] bg-[size:16px_16px]" />
                </div>

                {/* Cyber Security Quick Specs */}
                <div className="space-y-3 font-mono text-xs">
                  <div className={`p-2.5 rounded-xl border flex items-center justify-between ${
                    theme === 'dark' ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'
                  }`}>
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-cyan-400" /> Current Role
                    </span>
                    <span className="text-cyan-400 font-semibold">Network Sec Eng</span>
                  </div>

                  <div className={`p-2.5 rounded-xl border flex items-center justify-between ${
                    theme === 'dark' ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'
                  }`}>
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5 text-emerald-400" /> Top Firewalls
                    </span>
                    <span className="text-emerald-400 font-semibold">Sophos & Fortinet</span>
                  </div>

                  <div className={`p-2.5 rounded-xl border flex items-center justify-between ${
                    theme === 'dark' ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'
                  }`}>
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-amber-400" /> Certifications
                    </span>
                    <span className="text-amber-400 font-semibold">5+ Verified</span>
                  </div>
                </div>

                {/* Footer Link inside card */}
                <div className="mt-5 pt-3 border-t border-slate-800/50 text-center">
                  <a
                    href="#contact"
                    className="text-xs font-mono text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1 font-semibold group"
                  >
                    <span>Initiate Secure Contact</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
