import React from 'react';
import { Award, Briefcase, CheckCircle2, ShieldCheck } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface StatsProps {
  theme: 'dark' | 'light';
}

export const Stats: React.FC<StatsProps> = ({ theme }) => {
  const statIcons = [
    <Briefcase key="1" className="w-6 h-6 text-cyan-400" />,
    <CheckCircle2 key="2" className="w-6 h-6 text-blue-400" />,
    <Award key="3" className="w-6 h-6 text-amber-400" />,
    <ShieldCheck key="4" className="w-6 h-6 text-emerald-400" />
  ];

  return (
    <section id="stats" className="py-12 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {PERSONAL_INFO.stats.map((stat, idx) => (
            <div
              key={stat.label}
              className={`p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1 ${
                theme === 'dark'
                  ? 'bg-slate-900/80 border-slate-800 hover:border-cyan-500/40 shadow-lg shadow-black/20'
                  : 'bg-white border-slate-200 hover:border-cyan-300 shadow-md'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-xl ${
                  theme === 'dark' ? 'bg-slate-800/80' : 'bg-slate-100'
                }`}>
                  {statIcons[idx % statIcons.length]}
                </div>
                <span className="text-xs font-mono text-cyan-500 font-bold uppercase tracking-widest">
                  STAT-0{idx + 1}
                </span>
              </div>
              <div className={`text-3xl sm:text-4xl font-extrabold tracking-tight font-mono mb-1 ${
                theme === 'dark' ? 'text-white' : 'text-slate-900'
              }`}>
                {stat.value}
              </div>
              <p className={`text-xs sm:text-sm font-medium ${
                theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
              }`}>
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
