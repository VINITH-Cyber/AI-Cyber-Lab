import React, { useState } from 'react';
import { Flame, Shield, Play, Copy, Check, RefreshCw, Terminal } from 'lucide-react';

interface FirewallSimProps {
  theme: 'dark' | 'light';
}

export const FirewallSimulator: React.FC<FirewallSimProps> = ({ theme }) => {
  const [vendor, setVendor] = useState<'sophos' | 'fortinet' | 'cisco'>('fortinet');
  const [srcIp, setSrcIp] = useState('192.168.10.0/24');
  const [dstIp, setDstIp] = useState('10.0.0.5');
  const [port, setPort] = useState('443');
  const [protocol, setProtocol] = useState('TCP');
  const [action, setAction] = useState<'ACCEPT' | 'DENY'>('ACCEPT');
  const [copied, setCopied] = useState(false);

  // Generate Vendor Config Code Snippet
  const generateSnippet = () => {
    if (vendor === 'fortinet') {
      return `config firewall policy
    edit 101
        set name "Allow_Secure_Web_Traffic"
        set srcintf "port1_LAN"
        set dstintf "port2_WAN"
        set srcaddr "${srcIp}"
        set dstaddr "${dstIp}"
        set action ${action === 'ACCEPT' ? 'accept' : 'deny'}
        set schedule "always"
        set service "${protocol}_${port}"
        set logtraffic all
    next
end`;
    } else if (vendor === 'sophos') {
      return `// Sophos SFOS v21 Policy Rule
Rule Name: FW_RULE_RAILWAY_APP
Source Zone: LAN (${srcIp})
Destination Zone: WAN (${dstIp})
Services: ${protocol}:${port}
Action: ${action}
Security Features: Web Filter = Active, IPS = High Risk Prevention, Malware Scanning = Enabled`;
    } else {
      return `access-list OUTSIDE_IN extended ${action === 'ACCEPT' ? 'permit' : 'deny'} ${protocol.toLowerCase()} ${srcIp} host ${dstIp} eq ${port}
access-group OUTSIDE_IN in interface outside`;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generateSnippet());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="py-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`p-8 rounded-3xl border ${
          theme === 'dark'
            ? 'bg-slate-900/90 border-slate-800 shadow-2xl'
            : 'bg-white border-slate-200 shadow-xl'
        }`}>
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800/60 mb-8">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 mb-2">
                <Flame className="w-3.5 h-3.5" />
                <span>INTERACTIVE SECURITY UTILITY</span>
              </div>
              <h3 className={`text-2xl font-extrabold ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                Firewall Rule Generator & Policy Auditor
              </h3>
              <p className={`text-xs sm:text-sm ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
                Simulate firewall policy generation across Fortinet FortiGate, Sophos SFOS v21, and Cisco FMC rulebases.
              </p>
            </div>

            {/* Vendor Selector */}
            <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
              <button
                onClick={() => setVendor('fortinet')}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
                  vendor === 'fortinet' ? 'bg-orange-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                FortiGate
              </button>
              <button
                onClick={() => setVendor('sophos')}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
                  vendor === 'sophos' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                Sophos SFOS
              </button>
              <button
                onClick={() => setVendor('cisco')}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all ${
                  vendor === 'cisco' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                Cisco FMC
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Input Controls Form */}
            <div className="lg:col-span-5 space-y-4">
              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 mb-1">
                  Source Subnet / IP
                </label>
                <input
                  type="text"
                  value={srcIp}
                  onChange={(e) => setSrcIp(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-mono border focus:outline-none focus:border-cyan-500 ${
                    theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 mb-1">
                  Destination IP
                </label>
                <input
                  type="text"
                  value={dstIp}
                  onChange={(e) => setDstIp(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-mono border focus:outline-none focus:border-cyan-500 ${
                    theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1">
                    Port
                  </label>
                  <input
                    type="text"
                    value={port}
                    onChange={(e) => setPort(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-mono border focus:outline-none focus:border-cyan-500 ${
                      theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 mb-1">
                    Protocol
                  </label>
                  <select
                    value={protocol}
                    onChange={(e) => setProtocol(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl text-xs font-mono border focus:outline-none focus:border-cyan-500 ${
                      theme === 'dark' ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'
                    }`}
                  >
                    <option value="TCP">TCP</option>
                    <option value="UDP">UDP</option>
                    <option value="ICMP">ICMP</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 mb-1">
                  Action
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setAction('ACCEPT')}
                    className={`py-2 rounded-xl text-xs font-mono font-bold border transition-all ${
                      action === 'ACCEPT'
                        ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    ALLOW / ACCEPT
                  </button>
                  <button
                    onClick={() => setAction('DENY')}
                    className={`py-2 rounded-xl text-xs font-mono font-bold border transition-all ${
                      action === 'DENY'
                        ? 'bg-rose-500/20 text-rose-400 border-rose-500/50'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    DENY / DROP
                  </button>
                </div>
              </div>
            </div>

            {/* Generated Output Snippet Terminal */}
            <div className="lg:col-span-7">
              <div className="rounded-2xl bg-slate-950 border border-slate-800 p-5 font-mono text-xs text-slate-200 relative group shadow-inner">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400 font-bold uppercase">
                      Generated {vendor.toUpperCase()} CLI Script
                    </span>
                  </div>
                  <button
                    onClick={handleCopy}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 hover:text-white transition-colors flex items-center gap-1.5"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy Code'}</span>
                  </button>
                </div>

                <pre className="overflow-x-auto text-emerald-300 font-mono leading-relaxed p-2">
                  <code>{generateSnippet()}</code>
                </pre>
              </div>

              <p className="mt-3 text-[11px] font-mono text-slate-500 text-right">
                * Built by Vinith N to demonstrate multi-vendor CLI policy syntax & firewall administration skills.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
