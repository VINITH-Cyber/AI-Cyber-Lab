import React from 'react';
import { User, Shield, Server, Terminal, Lock, Cpu, Globe } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface AboutProps {
  theme: 'dark' | 'light';
}

export const About: React.FC<AboutProps> = ({ theme }) => {
  const highlights = [
    { icon: <Shield className="w-5 h-5 text-cyan-400" />, title: 'Firewall Administration', desc: 'Sophos XGS v21, Fortinet FortiGate 7.6, Cisco FMC' },
    { icon: <Server className="w-5 h-5 text-blue-400" />, title: 'Server & Patch Mgmt', desc: 'Windows Server, Active Directory, WSUS, Ubuntu' },
    { icon: <Terminal className="w-5 h-5 text-emerald-400" />, title: 'VAPT & Ethical Hacking', desc: 'Burp Suite Pro, Nmap, Wireshark, Nessus, Metasploit' },
    { icon: <Cpu className="w-5 h-5 text-amber-400" />, title: 'Python Security Ops', desc: 'Custom CLI tools, syslog parsers, policy auditors' }
  ];

  return (
    <section id="about" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <User className="w-3.5 h-3.5" />
            <span>BIOGRAPHY</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            theme === 'dark' ? 'text-white' : 'text-slate-900'
          }`}>
            About <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Vinith N</span>
          </h2>
          <p className={`text-sm sm:text-base ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
            Dedicated Network Security Engineer protecting critical enterprise infrastructures and automating defense workflows.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Main Bio Text */}
          <div className={`lg:col-span-7 p-8 rounded-2xl border space-y-6 ${
            theme === 'dark'
              ? 'bg-slate-900/70 border-slate-800 text-slate-300'
              : 'bg-white border-slate-200 text-slate-700 shadow-lg shadow-slate-100'
          }`}>
            <h3 className={`text-xl font-bold flex items-center gap-2.5 ${
              theme === 'dark' ? 'text-white' : 'text-slate-900'
            }`}>
              <Lock className="w-5 h-5 text-cyan-500" />
              <span>Passionate Perimeter Security Specialist</span>
            </h3>

            <p className="leading-relaxed text-sm sm:text-base">
              Hello! I'm <strong className="text-cyan-400">Vinith N</strong>, a hands-on Network Security Engineer with proven expertise in enterprise network architecture, firewall administration, vulnerability assessment, penetration testing, and security patch automation.
            </p>

            <p className="leading-relaxed text-sm sm:text-base">
              I have delivered critical security projects, including perimeter firewall deployment and hardening for major railway infrastructure, automated patch management for enterprise Windows Servers, and comprehensive vulnerability remediation. My toolset includes Sophos Firewall, Fortinet FortiGate, Cisco FMC, Burp Suite, Nmap, Wireshark, Tenable Nessus, and Kali Linux.
            </p>

            <p className="leading-relaxed text-sm sm:text-base">
              In addition to network security, I build custom Python scripts and AI-driven automation solutions to parse complex logs, eliminate manual SOC overhead, and streamline security operations. My goal is to continuously master emerging threat vectors and build resilient digital defenses.
            </p>

            {/* Location & Details row */}
            <div className="pt-4 border-t border-slate-800/60 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
              <div className="flex items-center gap-2 text-slate-400">
                <Globe className="w-4 h-4 text-cyan-400" />
                <span>Based in: <strong className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>Tamil Nadu, India</strong></span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>Specialization: <strong className={theme === 'dark' ? 'text-white' : 'text-slate-900'}>Firewall & Cyber Security</strong></span>
              </div>
            </div>
          </div>

          {/* Core Pillars Cards */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
            {highlights.map((item) => (
              <div
                key={item.title}
                className={`p-5 rounded-xl border transition-all duration-200 hover:border-cyan-500/40 ${
                  theme === 'dark'
                    ? 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-900'
                    : 'bg-slate-50 border-slate-200 hover:bg-white hover:shadow-md'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div className={`p-2.5 rounded-xl border shrink-0 ${
                    theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200'
                  }`}>
                    {item.icon}
                  </div>
                  <div>
                    <h4 className={`text-sm font-bold mb-1 ${
                      theme === 'dark' ? 'text-white' : 'text-slate-900'
                    }`}>
                      {item.title}
                    </h4>
                    <p className={`text-xs ${
                      theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
                    }`}>
                      {item.desc}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
