import React from 'react';
import { Shield, ArrowUp } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface FooterProps {
  theme: 'dark' | 'light';
}

export const Footer: React.FC<FooterProps> = ({ theme }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className={`border-t py-12 transition-colors ${
      theme === 'dark'
        ? 'bg-slate-950 border-slate-800/80 text-slate-400'
        : 'bg-slate-100 border-slate-200 text-slate-600'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand & Subtitle */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-md">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <span className={`font-bold text-base block ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                {PERSONAL_INFO.name}
              </span>
              <span className="text-xs font-mono text-cyan-400 block font-medium">
                Network Security Engineer | Cyber Security | AI Solutions
              </span>
            </div>
          </div>

          {/* Copyright text */}
          <div className="text-xs font-mono text-center">
            <p>© 2026 Vinith N. All Rights Reserved.</p>
          </div>

          {/* Back to top button */}
          <button
            onClick={scrollToTop}
            className={`p-3 rounded-xl border transition-all hover:-translate-y-1 ${
              theme === 'dark'
                ? 'bg-slate-900 border-slate-800 text-cyan-400 hover:border-cyan-500/40'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-sm'
            }`}
            title="Scroll to Top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};
