import React, { useState } from 'react';
import { ShieldAlert, Bug, Terminal, ExternalLink, ChevronRight, CheckCircle2, Award, X } from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { ProjectItem } from '../types';

interface ProjectsProps {
  theme: 'dark' | 'light';
}

export const Projects: React.FC<ProjectsProps> = ({ theme }) => {
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldAlert':
        return <ShieldAlert className="w-6 h-6 text-cyan-400" />;
      case 'Bug':
        return <Bug className="w-6 h-6 text-red-400" />;
      case 'Terminal':
        return <Terminal className="w-6 h-6 text-emerald-400" />;
      default:
        return <ShieldAlert className="w-6 h-6 text-cyan-400" />;
    }
  };

  return (
    <section id="projects" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Award className="w-3.5 h-3.5" />
            <span>CASE STUDIES</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            theme === 'dark' ? 'text-white' : 'text-slate-900'
          }`}>
            Featured <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Projects</span>
          </h2>
          <p className={`text-sm sm:text-base ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
            Real-world security deployments, web application VAPT assessments, and Python security automation tooling.
          </p>
        </div>

        {/* Projects Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PROJECTS.map((project) => (
            <div
              key={project.id}
              className={`p-7 rounded-2xl border transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl flex flex-col justify-between group ${
                theme === 'dark'
                  ? 'bg-slate-900/80 border-slate-800 hover:border-cyan-500/50 shadow-lg'
                  : 'bg-white border-slate-200 hover:border-cyan-400 shadow-md'
              }`}
            >
              <div>
                {/* Header Badge */}
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl border ${
                    theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
                  }`}>
                    {getIcon(project.iconName)}
                  </div>
                  <span className="px-3 py-1 rounded-full text-[11px] font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                    {project.category}
                  </span>
                </div>

                <h3 className={`text-xl font-bold mb-1 group-hover:text-cyan-400 transition-colors ${
                  theme === 'dark' ? 'text-white' : 'text-slate-900'
                }`}>
                  {project.title}
                </h3>

                <p className="text-xs font-mono text-cyan-500 mb-3 font-semibold">
                  {project.subtitle}
                </p>

                <p className={`text-xs sm:text-sm leading-relaxed mb-6 ${
                  theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  {project.description}
                </p>

                {/* Key Metric Badge if present */}
                {project.metrics && (
                  <div className="mb-5 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{project.metrics}</span>
                  </div>
                )}
              </div>

              <div>
                {/* Tech Tags */}
                <div className="flex flex-wrap gap-1.5 mb-6">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-mono ${
                        theme === 'dark'
                          ? 'bg-slate-950 text-slate-300 border border-slate-800'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Detailed view action button */}
                <button
                  onClick={() => setSelectedProject(project)}
                  className={`w-full py-2.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center justify-center gap-2 ${
                    theme === 'dark'
                      ? 'bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 border border-slate-700'
                      : 'bg-slate-100 hover:bg-slate-900 hover:text-white text-slate-800 border border-slate-200'
                  }`}
                >
                  <span>Project Deep Dive</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed Project Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className={`relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border p-6 sm:p-8 shadow-2xl ${
            theme === 'dark' ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <button
              onClick={() => setSelectedProject(null)}
              className="absolute top-4 right-4 p-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                {getIcon(selectedProject.iconName)}
              </div>
              <div>
                <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">
                  {selectedProject.category}
                </span>
                <h3 className="text-2xl font-extrabold">{selectedProject.title}</h3>
              </div>
            </div>

            <p className="text-sm font-mono text-cyan-400 mb-6 font-medium">
              {selectedProject.subtitle}
            </p>

            <div className="space-y-6">
              <div>
                <h4 className="text-xs font-mono font-bold uppercase text-slate-400 mb-2">Overview</h4>
                <p className={`text-sm leading-relaxed ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                  {selectedProject.longDescription || selectedProject.description}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-mono font-bold uppercase text-slate-400 mb-3">Key Deliverables & Execution</h4>
                <ul className="space-y-2 text-sm">
                  {selectedProject.keyHighlights.map((highlight, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className={theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}>
                        {highlight}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-xs font-mono font-bold uppercase text-slate-400 mb-2">Technologies Utilized</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedProject.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 rounded-lg text-xs font-mono font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedProject(null)}
                className="px-6 py-2.5 rounded-xl font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950"
              >
                Close Project
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
