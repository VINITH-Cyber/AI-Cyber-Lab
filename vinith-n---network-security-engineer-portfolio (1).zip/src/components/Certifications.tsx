import React, { useState } from 'react';
import { Award, ShieldCheck, Flame, Laptop, Wifi, Radio, Cloud, CheckCircle, ExternalLink, X } from 'lucide-react';
import { CERTIFICATIONS } from '../data/portfolioData';
import { CertificationItem } from '../types';

interface CertsProps {
  theme: 'dark' | 'light';
}

export const Certifications: React.FC<CertsProps> = ({ theme }) => {
  const [activeCert, setActiveCert] = useState<CertificationItem | null>(null);

  const certIcons: Record<string, React.ReactNode> = {
    ShieldCheck: <ShieldCheck className="w-7 h-7 text-red-400" />,
    Flame: <Flame className="w-7 h-7 text-cyan-400" />,
    Laptop: <Laptop className="w-7 h-7 text-blue-400" />,
    Wifi: <Wifi className="w-7 h-7 text-emerald-400" />,
    Radio: <Radio className="w-7 h-7 text-indigo-400" />,
    Cloud: <Cloud className="w-7 h-7 text-amber-400" />
  };

  return (
    <section id="certifications" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Award className="w-3.5 h-3.5" />
            <span>CREDENTIALS</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            theme === 'dark' ? 'text-white' : 'text-slate-900'
          }`}>
            Professional <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">Certifications</span>
          </h2>
          <p className={`text-sm sm:text-base ${theme === 'dark' ? 'text-slate-400' : 'text-slate-600'}`}>
            Industry-recognized vendor certifications validating firewall, endpoint security, wireless architecture, and cloud skills.
          </p>
        </div>

        {/* Certifications Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CERTIFICATIONS.map((cert) => (
            <div
              key={cert.id}
              onClick={() => setActiveCert(cert)}
              className={`p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between group relative overflow-hidden ${
                theme === 'dark'
                  ? 'bg-slate-900/80 border-slate-800 hover:border-cyan-500/50 shadow-lg'
                  : 'bg-white border-slate-200 hover:border-cyan-400 shadow-md'
              }`}
            >
              {/* Subtle top color gradient strip */}
              <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${cert.badgeBg}`} />

              <div>
                {/* Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-2xl border ${
                    theme === 'dark' ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
                  }`}>
                    {certIcons[cert.iconName] || <Award className="w-7 h-7 text-cyan-400" />}
                  </div>

                  {cert.verified && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Verified</span>
                    </span>
                  )}
                </div>

                <h3 className={`text-lg font-bold mb-1 group-hover:text-cyan-400 transition-colors ${
                  theme === 'dark' ? 'text-white' : 'text-slate-900'
                }`}>
                  {cert.title}
                </h3>

                <p className="text-xs font-mono font-semibold text-cyan-400 mb-1">
                  {cert.code}
                </p>

                <p className={`text-xs font-mono mb-4 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                  Issuer: <span className="font-semibold">{cert.issuer}</span>
                </p>

                <p className={`text-xs line-clamp-2 leading-relaxed mb-4 ${
                  theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  {cert.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">{cert.issueDate}</span>
                <span className="text-cyan-400 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-1">
                  <span>View Details</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Certification Details Modal */}
      {activeCert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className={`relative w-full max-w-xl rounded-2xl border p-6 sm:p-8 shadow-2xl ${
            theme === 'dark' ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <button
              onClick={() => setActiveCert(null)}
              className="absolute top-4 right-4 p-2 rounded-xl border border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4 mb-6">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                {certIcons[activeCert.iconName]}
              </div>
              <div>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 mb-1">
                  <CheckCircle className="w-3 h-3" /> Verified Credential
                </span>
                <h3 className="text-xl font-extrabold">{activeCert.title}</h3>
                <p className="text-xs font-mono text-cyan-400">{activeCert.code} — {activeCert.issuer}</p>
              </div>
            </div>

            <p className={`text-sm leading-relaxed mb-6 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
              {activeCert.description}
            </p>

            <div className="mb-6">
              <h4 className="text-xs font-mono font-bold uppercase text-slate-400 mb-3">Verified Skills & Domains</h4>
              <div className="flex flex-wrap gap-2">
                {activeCert.skillsVerified.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1 rounded-lg text-xs font-mono font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs font-mono text-slate-400">Status: Active & Valid</span>
              <button
                onClick={() => setActiveCert(null)}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-cyan-500 text-slate-950 hover:bg-cyan-400"
              >
                Close View
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
