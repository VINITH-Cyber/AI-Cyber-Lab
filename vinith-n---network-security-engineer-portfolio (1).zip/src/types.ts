export interface SkillItem {
  id: string;
  name: string;
  category: 'firewall' | 'network' | 'server' | 'vulnerability' | 'automation' | 'tools';
  icon: string;
  level: number; // percentage
  description: string;
  technologies: string[];
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  period: string;
  type: string;
  location: string;
  responsibilities: string[];
  skillsUsed: string[];
}

export interface ProjectItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  longDescription?: string;
  keyHighlights: string[];
  tags: string[];
  category: 'Network Security' | 'Penetration Testing' | 'Automation & AI';
  iconName: string;
  metrics?: string;
}

export interface CertificationItem {
  id: string;
  title: string;
  issuer: string;
  code: string;
  badgeBg: string;
  iconName: string;
  verified: boolean;
  issueDate: string;
  description: string;
  skillsVerified: string[];
}

export interface ContactFormState {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface SentMessage extends ContactFormState {
  id: string;
  timestamp: string;
}
