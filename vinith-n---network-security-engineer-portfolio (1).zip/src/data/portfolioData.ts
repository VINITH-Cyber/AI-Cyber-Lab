import { ExperienceItem, ProjectItem, CertificationItem, SkillItem } from '../types';

export const PERSONAL_INFO = {
  name: 'Vinith N',
  title: 'Network Security Engineer',
  tagline: 'Securing Networks | Cyber Security | Python Automation | AI Solutions',
  email: 'vinithpalani1@gmail.com',
  location: 'Tamil Nadu, India',
  linkedin: 'https://www.linkedin.com/in/vinith-n/',
  github: 'https://github.com/VINITH-Cyber',
  typingRoles: [
    'Network Security Engineer',
    'Firewall Administrator (Sophos & Fortinet)',
    'Penetration Tester & Vulnerability Assessor',
    'Python & AI Security Tools Developer'
  ],
  aboutBio: `Hello! I'm Vinith N, a passionate Network Security Engineer with hands-on experience in enterprise network infrastructure, firewall administration, vulnerability assessment, penetration testing, and secure solution deployment.

I have worked on real-world enterprise network security projects involving multi-vendor firewall configuration, Windows Server patch management, vulnerability remediation, and secure network deployment (including high-security railway infrastructure). I am thoroughly experienced with industry security tools such as Burp Suite, Nmap, Wireshark, Tenable Nessus, Metasploit, and Kali Linux.

Alongside network security, I enjoy developing Python automation scripts and AI-powered security tools that streamline security operations, automate log parsing, and improve SOC productivity. My primary goal is to continuously master emerging cybersecurity paradigms, harden enterprise perimeters, and build resilient digital infrastructures.`,
  stats: [
    { label: 'Years Experience', value: '2+', suffix: '' },
    { label: 'Projects Completed', value: '20+', suffix: '' },
    { label: 'Certifications', value: '5+', suffix: '' },
    { label: 'Security Tools & Platforms', value: '15+', suffix: '' }
  ]
};

export const EXPERIENCES: ExperienceItem[] = [
  {
    id: 'gts-technosoft',
    role: 'Network Security Engineer',
    company: 'GTS Technosoft Pvt. Ltd.',
    period: 'Present',
    type: 'Full-Time',
    location: 'Maharastra , India',
    responsibilities: [
      'Managing and monitoring enterprise network security infrastructure across diverse multi-site deployments.',
      'Configuring, administering, and troubleshooting Sophos Firewall (XGS/XG v21.0), Fortinet FortiGate (7.6), and Cisco FMC solutions.',
      'Performing periodic vulnerability assessments (VAPT), vulnerability prioritization via CVSS, and coordinating remediation.',
      'Implementing automated Windows Server patch management, Active Directory security policies, and system hardening.',
      'Leading network security architecture projects, railway network deployments, and site-to-site IPsec / SSL VPN configurations.'
    ],
    skillsUsed: ['Sophos Firewall', 'Fortinet FortiGate', 'Cisco FMC', 'Windows Server', 'Vulnerability Remediation', 'IPsec VPN']
  },
  {
    id: 'cybernerds',
    role: 'Cyber Security Intern',
    company: 'Cybernerds Solution Pvt. Ltd.',
    period: 'Previous',
    type: 'Internship',
    location: 'Tamil Nadu, India',
    responsibilities: [
      'Assisted in web application vulnerability assessments and penetration testing using OWASP Top 10 guidelines.',
      'Utilized security inspection tools including Burp Suite Professional, Nmap network mapper, Wireshark packet analyzer, and Kali Linux toolsets.',
      'Supported senior security architects in perimeter firewall policy definitions and network rule hardening.',
      'Drafted comprehensive VAPT security assessment reports, risk classification matrices, and technical remediation guides.',
      'Studied enterprise cybersecurity operations, incident triage, and network security best practices.'
    ],
    skillsUsed: ['Burp Suite', 'Nmap', 'Wireshark', 'Kali Linux', 'OWASP Top 10', 'Penetration Testing']
  }
];

export const TECHNICAL_EXPERTISE = [
  {
    id: 'firewall',
    title: 'Firewall Administration',
    icon: 'Flame',
    description: 'Expertise in configuring, managing, and troubleshooting Sophos Firewall, Fortinet FortiGate, and Cisco Secure Firewall Management Center (FMC) for enterprise network security.',
    tags: ['Sophos XGS (v21.0)', 'Fortinet FortiGate (7.6)', 'Cisco FMC', 'NAT / PAT', 'HA Clustering', 'SD-WAN']
  },
  {
    id: 'network-sec',
    title: 'Network Security & Hardening',
    icon: 'Shield',
    description: 'Enterprise network security implementation, firewall policy management, IPsec & SSL VPN configuration, 802.1X access control, network segmentation, and perimeter defense.',
    tags: ['IPsec / SSL VPN', 'VLAN Segmentation', 'Access Control Lists (ACLs)', 'IDS / IPS', 'WAF', 'DDoS Mitigation']
  },
  {
    id: 'server-admin',
    title: 'Server Administration',
    icon: 'Server',
    description: 'Installation, configuration, automated patch management, Active Directory GPO enforcement, and OS level troubleshooting for Windows Server, Ubuntu Server, and Kali Linux.',
    tags: ['Windows Server 2019/2022', 'WSUS / Patching', 'Ubuntu Server', 'Kali Linux', 'Active Directory', 'System Hardening']
  },
  {
    id: 'vapt',
    title: 'Vulnerability Assessment & VAPT',
    icon: 'Search',
    description: 'Conducting structured security assessments, web application penetration testing (OWASP Top 10), flaw identification, CVSS risk rating, and remediation validation.',
    tags: ['OWASP Top 10', 'Web App Pen Testing', 'VAPT Reporting', 'Remediation Verification', 'Risk Scoring']
  },
  {
    id: 'automation',
    title: 'Python Security Automation',
    icon: 'Code',
    description: 'Developing custom Python scripts to automate repetitive security tasks, parse syslog streams, verify firewall rule consistency, and generate security reports.',
    tags: ['Python 3', 'Log Parsing', 'Scapy / Socket', 'REST APIs', 'CLI Tooling', 'AI Scripting']
  },
  {
    id: 'audit',
    title: 'Network Audit & Architecture Review',
    icon: 'FileSearch',
    description: 'Performing comprehensive network audits to evaluate topology health, device configurations, compliance postures, and access policies to mitigate security gaps.',
    tags: ['Topology Mapping', 'Rulebase Auditing', 'Compliance Checks', 'Security Gap Analysis', 'Config Hardening']
  },
  {
    id: 'nessus',
    title: 'Vulnerability Management (Nessus)',
    icon: 'Target',
    description: 'Executing authenticated and unauthenticated network vulnerability scans using Tenable Nessus, analyzing findings, prioritizing remediation, and validating fixes via re-scans.',
    tags: ['Tenable Nessus', 'CVSS v3/v4', 'Asset Discovery', 'Patch Verification', 'Executive Summary Reports']
  },
  {
    id: 'sec-tools',
    title: 'Security Tooling & Platforms',
    icon: 'Wrench',
    description: 'Hands-on operational mastery of industry-standard security and ethical hacking software in enterprise and lab environments.',
    tags: ['Burp Suite', 'Nmap', 'Wireshark', 'Tenable Nessus', 'Metasploit Framework', 'Ruckus SmartZone / Wi-Fi']
  }
];

export const PROJECTS: ProjectItem[] = [
  {
    id: 'railway-security',
    title: 'Railway Infrastructure Network Security',
    subtitle: 'Enterprise Firewall & Infrastructure Hardening',
    description: 'Implemented comprehensive enterprise network security solutions for critical railway infrastructure, including multi-site firewall deployment, server hardening, Windows patch management, and vulnerability remediation.',
    longDescription: 'Engineered a multi-layered security architecture for mission-critical railway communications and control networks. Designed strict firewall access rules on Sophos and FortiGate appliances, established encrypted site-to-site IPsec VPN tunnels across remote railway junctions, and executed WSUS automated patch management for critical Windows Servers. Conducted end-to-end vulnerability scans and successfully remediated perimeter and internal flaws.',
    keyHighlights: [
      'Deployed HA FortiGate and Sophos firewalls across high-uptime railway operations.',
      'Configured automated patch deployment pipelines for enterprise Windows Servers.',
      'Remediated 100+ identified network and OS vulnerabilities with zero operational downtime.',
      'Segmented operational technology (OT) traffic from administrative corporate networks.'
    ],
    tags: ['Firewall', 'Windows Server', 'Network Security', 'FortiGate', 'Sophos', 'Vulnerability Remediation'],
    category: 'Network Security',
    iconName: 'ShieldAlert',
    metrics: '99.99% Uptime & Zero Security Incidents'
  },
  {
    id: 'webapp-pentest',
    title: 'Web Application Penetration Testing',
    subtitle: 'OWASP Security Assessment & Vulnerability Exploitation',
    description: 'Performed extensive web application security assessments using OWASP methodology to identify, validate, and document critical vulnerabilities such as SQL Injection, XSS, IDOR, and Security Misconfigurations.',
    longDescription: 'Simulated real-world adversary attack vectors against target web applications. Leveraged Burp Suite Professional for manual request manipulation, parameter tampering, and logic flaw analysis. Documented actionable proof-of-concept exploits for SQL Injection, Cross-Site Scripting (XSS), Insecure Direct Object References (IDOR), and weak authentication mechanisms, providing developers with clear code-level remediation steps.',
    keyHighlights: [
      'Identified critical & high severity flaws across authentication and API endpoints.',
      'Delivered detailed executive VAPT reports with step-by-step reproduction steps.',
      'Provided precise code & configuration recommendations to secure modern web frameworks.',
      'Validated fix implementations through structured re-testing cycles.'
    ],
    tags: ['Burp Suite', 'OWASP Top 10', 'Kali Linux', 'Nmap', 'Web Security', 'Penetration Testing'],
    category: 'Penetration Testing',
    iconName: 'Bug',
    metrics: '35+ Flaws Identified & Remediated'
  },
  {
    id: 'python-security-automation',
    title: 'Python Security Automation & Log Analyzer',
    subtitle: 'Automated Log Parsing, Threat Auditing & AI Summaries',
    description: 'Developed Python automation utilities to streamline security operations, parse multi-vendor firewall syslog records, verify policy anomalies, and generate automated executive summary reports.',
    longDescription: 'Built a lightweight Python toolkit designed for security engineers to automate manual investigation tasks. Includes log parsing modules for Syslog / CEF format, firewall shadow rule detection, open port vulnerability checks via Nmap wrappers, and an AI-driven security policy analyzer that translates complex rulebases into plain-English security postures.',
    keyHighlights: [
      'Reduced log review time by 75% via automated Python log parsing scripts.',
      'Built custom firewall rule base audit module to identify redundant or over-permissive ACLs.',
      'Integrated AI-assisted threat summary generator for SOC analyst quick review.',
      'Generated standardized Markdown and PDF reports for management audits.'
    ],
    tags: ['Python', 'Automation', 'Cyber Security', 'AI', 'Log Analysis', 'Firewall Audit'],
    category: 'Automation & AI',
    iconName: 'Terminal',
    metrics: '75% Faster Log & Policy Analysis'
  }
];

export const CERTIFICATIONS: CertificationItem[] = [
  {
    id: 'fortinet-fcp',
    title: 'Fortinet Certified Professional',
    issuer: 'Fortinet',
    code: 'FortiGate Administrator 7.6',
    badgeBg: 'from-red-600/20 to-orange-600/20 border-red-500/30',
    iconName: 'ShieldCheck',
    verified: true,
    issueDate: '2024 / 2025',
    description: 'Validates expertise in configuring, operating, and managing FortiGate Next-Generation Firewalls (NGFW), FortiOS 7.6 features, security policies, IPsec VPNs, and inspection modes.',
    skillsVerified: ['FortiOS 7.6', 'FortiGate NGFW', 'IPsec & SSL VPN', 'Security Policies', 'Antivirus & IPS', 'HA Clustering']
  },
  {
    id: 'sophos-firewall',
    title: 'Sophos Firewall Engineer',
    issuer: 'Sophos',
    code: 'Version 21.0',
    badgeBg: 'from-blue-600/20 to-cyan-600/20 border-blue-500/30',
    iconName: 'Flame',
    verified: true,
    issueDate: '2024',
    description: 'Demonstrates professional competence in setting up Sophos XGS Firewalls, SFOS v21, Synchronized Security, Web Protection, Intrusion Prevention, and SD-WAN routing.',
    skillsVerified: ['Sophos SFOS v21', 'XGS Series Hardware', 'Synchronized Security', 'WAF & IPS', 'User Authentication', 'SD-WAN']
  },
  {
    id: 'sophos-endpoint',
    title: 'Sophos Central Endpoint Protection',
    issuer: 'Sophos',
    code: 'Engineer Certification',
    badgeBg: 'from-sky-600/20 to-teal-600/20 border-sky-500/30',
    iconName: 'Laptop',
    verified: true,
    issueDate: '2024',
    description: 'Certifies mastery in deploying and managing Sophos Central Endpoint, Intercept X, EDR/XDR policies, threat prevention, and centralized endpoint management.',
    skillsVerified: ['Sophos Central', 'Intercept X Advanced', 'Endpoint Policy Deployment', 'Ransomware Protection', 'EDR/XDR']
  },
  {
    id: 'ruckus-smartzone',
    title: 'Ruckus SmartZone Administrator',
    issuer: 'CommScope Ruckus',
    code: 'RASZA',
    badgeBg: 'from-emerald-600/20 to-green-600/20 border-emerald-500/30',
    iconName: 'Wifi',
    verified: true,
    issueDate: '2023 / 2024',
    description: 'Validates technical skills in administering Ruckus SmartZone network controllers, Access Point provisioning, WLAN security, captive portals, and radio management.',
    skillsVerified: ['SmartZone Controller', 'WLAN Security', '802.1X Enterprise', 'AP Management', 'Guest Access Portal']
  },
  {
    id: 'ruckus-wifi-designer',
    title: 'Ruckus Accredited Wi-Fi Designer',
    issuer: 'CommScope Ruckus',
    code: 'RAWD',
    badgeBg: 'from-indigo-600/20 to-violet-600/20 border-indigo-500/30',
    iconName: 'Radio',
    verified: true,
    issueDate: '2023',
    description: 'Demonstrates expertise in RF planning, wireless site surveys, channel layout optimization, density capacity design, and high-performance Wi-Fi deployments.',
    skillsVerified: ['RF Design & Planning', 'Wi-Fi 6 / 6E', 'Heatmap Analysis', 'Capacity Planning', 'Signal Propagation']
  },
  {
    id: 'aws-cloud-practitioner',
    title: 'AWS Certified Cloud Practitioner',
    issuer: 'Amazon Web Services',
    code: 'AWS CCP',
    badgeBg: 'from-amber-600/20 to-yellow-600/20 border-amber-500/30',
    iconName: 'Cloud',
    verified: true,
    issueDate: '2023',
    description: 'Validates overall understanding of AWS Cloud infrastructure, security groups, IAM policies, VPC networking, EC2, and cloud security architecture.',
    skillsVerified: ['AWS VPC Networking', 'Security Groups & NACLs', 'IAM Role Management', 'Cloud Security Best Practices', 'EC2 & S3']
  }
];

export const SECURITY_TOOLS = [
  { name: 'Sophos Firewall', cat: 'Firewall', icon: 'Flame' },
  { name: 'Fortinet FortiGate', cat: 'Firewall', icon: 'Shield' },
  { name: 'Cisco FMC', cat: 'Firewall', icon: 'Cpu' },
  { name: 'Tenable Nessus', cat: 'Vulnerability Scanning', icon: 'Target' },
  { name: 'Burp Suite Pro', cat: 'Web Security', icon: 'Bug' },
  { name: 'Nmap Mapper', cat: 'Network Discovery', icon: 'Radar' },
  { name: 'Wireshark Analyzer', cat: 'Packet Inspection', icon: 'Activity' },
  { name: 'Metasploit', cat: 'Penetration Testing', icon: 'Zap' },
  { name: 'Kali Linux OS', cat: 'Security OS', icon: 'Terminal' },
  { name: 'Windows Server', cat: 'OS & Active Directory', icon: 'Server' },
  { name: 'Python Automation', cat: 'Scripting', icon: 'Code' },
  { name: 'Ruckus SmartZone', cat: 'Wireless Network', icon: 'Wifi' }
];
